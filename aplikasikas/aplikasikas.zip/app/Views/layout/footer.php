<footer>
    <p class="bg-light text-dark p-3">
        <strong>Copyright &copy; 2023 <a href="" class="text-decoration-none">KAS RT 04/RW 02</a>.</strong>
        All rights reserved.
    </p>
</footer>