<footer>
    <p class="bg-light text-dark p-3">
    Made with <span id="icon-love" class="et-pb-icon et-waypoint et_pb_animation_top et-animated">&#10084;</span> by <a href="http://koys.my.id" target="_blank">Bekoy</a>
    </p>
</footer>