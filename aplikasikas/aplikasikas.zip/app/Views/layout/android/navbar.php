        <nav class="navbar navbar-expand-lg bg-light fixed-top">
            <div class="container">
            <a class="navbar-brand" href="<?= base_url('/'); ?>"><span style="color: blue; font-weight: bold;">RT 04/RW 02 TDI & Kartika</span></a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                    <div class="navbar-nav">
                        <a class="nav-link active" aria-current="/" href="<?= base_url('/'); ?>">Home</a>
                        <a class="nav-link" href="<?= base_url('/Warga'); ?>">Warga</a>
                        <a class="nav-link" href="<?= base_url('/Iuran'); ?>">Iuran</a>
                        <a class="nav-link" href="<?= base_url('/Laporan'); ?>">Laporan</a>
                    </div>
                </div>
            </div>
        </nav>